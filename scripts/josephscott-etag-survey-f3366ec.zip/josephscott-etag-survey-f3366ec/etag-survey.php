<?php
# only a few options needed
# http://ak.quantcast.com/quantcast-top-million.zip
$quantcast_file = dirname( __FILE__ ) . '/Quantcast-Top-Million.txt';
$scan_this_many_sites = 1000;



# shouldn't need to change anything below here

if ( !is_readable( $quantcast_file ) ) {
	echo "The {$quantcast_file} is not readable.\n";
	exit;
}

$q_list = fopen( $quantcast_file, 'r' );
if ( !$q_list ) {
	echo "Unable to open {$quantcast_file} for reading.\n";
	exit;
}

$num_sites = 0;
$num_etags = 0;

define( 'ETAG_WORKS', 100 );
define( 'ETAG_WORKS_FARM', 200 );
define( 'ETAG_FAILS_CHANGE', 300 );
define( 'ETAG_FAILS_IGNORE', 400 );

$etag_works = 0;
$etag_works_farm = 0;
$etag_fails_change = 0;
$etag_fails_ignore = 0;

while ( ( $line = fgets( $q_list ) ) !== FALSE ) {
	# make sure we only process lines that have a hostname
	preg_match( '|^(\d+)\s+([\w\.\-]+)|', $line, $match );
	if ( empty( $match[2] ) ) {
		continue;
	}

	# we should have a valid entry at this point
	$rank = $match[1];
	$site = $match[2];

	$headers = http_headers( $site );
	$url = $headers['effective_url'];
	echo "[{$rank}] {$url} : ";

	$etag = '';
	if ( array_key_exists( 'ETag', $headers ) ) {
		$num_etags++;

		$etag = $headers['ETag'];
		echo "[ETAG] {$etag} - ";

		$result = verify_etag( $url, $etag );
		if ( $result == ETAG_WORKS ) {
			echo 'WORKS';
			$etag_works++;
		} elseif ( $result == ETAG_WORKS_FARM ) {
			echo 'WORKS, sort of, web server farm with different ETag values';
			$etag_works_farm++;
		} elseif ( $result == ETAG_FAILS_CHANGE ) {
			echo 'FAILS, the ETag value changes';
			$etag_fails_change++;
		} elseif ( $result == ETAG_FAILS_IGNORE ) {
			echo 'FAILS, ignored If-None-Match';
			$etag_fails_ignore++;
		}
	}

	echo "\n";
	$num_sites++;

	# bail out once we've hit our target
	if ( $num_sites >= $scan_this_many_sites ) {
		break;
	}
}

echo "\n\n";
echo "Checked {$num_sites} sites for ETag header, found {$num_etags}\n";
echo "Results\n";
echo "   WORKS: {$etag_works}\n";
echo "   WORKS, web farm: {$etag_works_farm}\n";
echo "   FAILS, changes: {$etag_fails_change}\n";
echo "   FAILS, ignored: {$etag_fails_ignore}\n";











function verify_etag( $url, $etag ) {
	# hit the URL again and see if ETags are processed correctly
	$try = http_headers( $url, array( "If-None-Match: {$etag}" ) );
	if ( $try['status'] == 304 ) {
		return ETAG_WORKS;
	} elseif ( $try['ETag'] != $etag ) {
		# there might be a farm of web servers,
		# see if we can get a match
		$farm_works = FALSE;
		for ( $i = 0; $i < 12; $i++ ) {
			$retry = http_headers( $url, array( "If-None-Match: {$etag}" ) );
			if ( !empty( $retry['ETag'] ) && $retry['ETag'] == $etag ) {
				return ETAG_WORKS_FARM;
				$farm_works = TRUE;
				break;
			}
		}

		if ( !$farm_works ) {
			return ETAG_FAILS_CHANGE;
		}
	} else {
		return ETAG_FAILS_IGNORE;
	}
}



function http_headers( $url, $req_headers = array() ) {
	# going to let curl figure out redirects and such
	$curl = curl_init();
	curl_setopt( $curl, CURLOPT_URL, $url );
	curl_setopt( $curl, CURLOPT_RETURNTRANSFER, TRUE );
	curl_setopt( $curl, CURLOPT_HEADER, TRUE );
	curl_setopt( $curl, CURLOPT_FOLLOWLOCATION, TRUE );
	curl_setopt( $curl, CURLOPT_MAXREDIRS, 50 );
	curl_setopt( $curl, CURLOPT_CONNECTTIMEOUT, 5 );
	curl_setopt( $curl, CURLOPT_TIMEOUT, 5 );
	curl_setopt( $curl, CURLOPT_HTTPHEADER, $req_headers );

	$data = curl_exec( $curl );
	$info = curl_getinfo( $curl );
	$http_status = curl_getinfo( $curl, CURLINFO_HTTP_CODE );
	$effective_url = curl_getinfo( $curl, CURLINFO_EFFECTIVE_URL );
	curl_close( $curl );

	$headers = array(
		'status' => $http_status,
		'effective_url' => $effective_url
	);
	$cookies = array();

	# grab the header section
	$header_string = trim( substr( $data, 0, $info['header_size'] ) );
	if ( strpos( $header_string, "\r\n\r\n" ) !== FALSE ) {
		$header_string = end( explode( "\r\n\r\n", $header_string ) );
		$header_string = str_replace( "\r\n", "\n", $header_string );
	}

	# build an array from the header key/values
	foreach ( explode( "\n", $header_string ) as $line ) {
		if ( strpos( $line, ':' ) === FALSE ) {
			continue;
		}

		list( $k, $v ) = explode( ':', $line, 2 );
		if ( empty( $v ) ) {
			continue;
		}

		if ( strtolower( $k ) == 'set-cookie' ) {
			$cookies[] = trim( $v );
		} else {
			$headers[$k] = trim( $v );
		}
	}

	return $headers;
}

